import React from 'react';
import NotFound from '../NotFound';

function NotFoundPage() {
  return <NotFound />;
}

export default NotFoundPage;
