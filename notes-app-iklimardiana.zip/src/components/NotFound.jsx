import React from "react";

function NotFound() {
    return (
        <div className="not-found">
            <h1>Oops! :( </h1>
            <h2>404 -Not Found</h2>
        </div>
    )
}

export default NotFound;